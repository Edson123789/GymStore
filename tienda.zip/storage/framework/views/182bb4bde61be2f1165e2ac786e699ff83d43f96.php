<?php $__env->startSection('user-content'); ?>
<main class="main">
    <div class="container">
        <div class="row mt-4">
            <div class="col-lg-9 order-lg-last dashboard-content">
                <h2>Mi perfil</h2>
                
                <form action="<?php echo e(route('editar_perfil')); ?>" role="form" method="POST">
                    <?php echo csrf_field(); ?>
                    <input name="_method" type="hidden" value="PATCH">
                    <div class="row">
                        <?php if(Session::has('success')): ?>
                            <div class="col-sm-11 form-group">
                                <div class="alert alert-success">
                                    <?php echo e(Session::get('success')); ?>

                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                            </div>
                        <?php endif; ?>
                        <?php if(Session::has('danger')): ?>
                        <div class="col-sm-11 form-group">
                            <div class="alert alert-danger">
                                <?php echo e(Session::get('danger')); ?>

                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                        </div>
                        <?php endif; ?>
                        <div class="col-sm-11">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group required-field">
                                        <label for="acc-name">Nombres</label>
                                        <input type="text" class="form-control" id="acc-name" name="name" required value="<?php echo e($usuario->name); ?>" placeholder="Nombres completos">
                                        <?php if($errors->has('name')): ?>
                                            <span class="help-block" style="color: #ff0000"><?php echo e($errors->first('name')); ?></span>
                                        <?php endif; ?>
                                    </div><!-- End .form-group -->
                                </div><!-- End .col-md-4 -->

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="acc-mname">Apellidos</label>
                                        <input type="text" class="form-control" id="acc-mname" name="fullname" value="<?php echo e($usuario->fullname); ?>" placeholder="Apellidos completos">
                                        <?php if($errors->has('fullname')): ?>
                                            <span class="help-block" style="color: #ff0000"><?php echo e($errors->first('fullname')); ?></span>
                                        <?php endif; ?>
                                    </div><!-- End .form-group -->
                                </div><!-- End .col-md-4 -->

                                <div class="col-sm-12 form-group required-field">
                                    <label for="acc-email">Correo electrónico</label>
                                    <input type="email" readonly class="form-control" id="acc-email" required value="<?php echo e($usuario->email); ?>">
                                </div><!-- End .form-group -->

                                <div class="col-sm-6 form-group required-field">
                                    <label for="acc-password">Contraseña nueva</label>
                                    <input type="password" class="form-control" id="acc-password" name="contraseña" autocomplete="new-password">
                                    <?php if($errors->has('password')): ?>
                                        <span class="help-block" style="color: #ff0000"><?php echo e($errors->first('password')); ?></span>
                                    <?php endif; ?>
                                </div><!-- End .form-group -->

                                <div class="col-sm-6 form-group required-field">
                                    <label for="acc-password">Confirmación</label>
                                    <input type="password" class="form-control" id="acc-password" name="password_confirmation">
                                </div><!-- End .form-group -->

                                <div class="col-sm-12 mt-4 text-right">
                                    <button type="submit" class="btn btn-primary">Actualizar</button>
                                </div>
                                
                            </div><!-- End .row -->
                        </div><!-- End .col-sm-11 -->
                    </div><!-- End .row -->
                 
                
                </form>
            </div><!-- End .col-lg-9 -->

            <aside class="sidebar col-lg-3">
                <div class="widget widget-dashboard">
                    <h3 class="widget-title">My Account</h3>

                    <ul class="list">
                        <li class="active"><a href="#">Account Dashboard</a></li>
                        <li><a href="#">Account Information</a></li>
                        <li><a href="#">Address Book</a></li>
                        <li><a href="#">My Orders</a></li>
                        <li><a href="#">Billing Agreements</a></li>
                        <li><a href="#">Recurring Profiles</a></li>
                        <li><a href="#">My Product Reviews</a></li>
                        <li><a href="#">My Tags</a></li>
                        <li><a href="#">My Wishlist</a></li>
                        <li><a href="#">My Applications</a></li>
                        <li><a href="#">Newsletter Subscriptions</a></li>
                        <li><a href="#">My Downloadable Products</a></li>
                    </ul>
                </div><!-- End .widget -->
            </aside><!-- End .col-lg-3 -->
        </div>
    </div>
</main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.users', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\tienda\resources\views/cuenta.blade.php ENDPATH**/ ?>