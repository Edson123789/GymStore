
<?php $__env->startSection('user-content'); ?>
<main class="main">
    <div class="container">
        <div class="row mt-4">
            <div class="col-lg-9">
                <?php 
    
                        $config = DB::table('configuraciones')
                        ->first();
                ?>
                <div class="product-single-container product-single-default">
                    <div class="row">
                        <div class="col-lg-7 col-md-6 product-single-gallery">
                            <div class="product-slider-container product-item">
                                <div class="product-single-carousel owl-carousel owl-theme">
                                    <?php $__currentLoopData = $galeria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="product-item">
                                            <img class="product-single-image" src="<?php echo e(asset('soporte_img/'.$item->foto)); ?>" data-zoom-image="<?php echo e(asset('soporte_img/'.$item->foto)); ?>"/>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <!-- End .product-single-carousel -->
                                <span class="prod-full-screen">
                                    <i class="icon-plus"></i>
                                </span>
                            </div>
                            <div class="prod-thumbnail row owl-dots" id='carousel-custom-dots'>
                                <?php $__currentLoopData = $galeria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-3 owl-dot">
                                        <img src="<?php echo e(asset('soporte_img/'.$item->foto)); ?>"/>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div><!-- End .col-lg-7 -->

                        <div class="col-lg-5 col-md-6">
                            <div class="product-single-details">
                                <h1 class="product-title"><?php echo e($producto->titulo); ?></h1>

                                <div class="ratings-container">
                                    <div class="product-ratings">
                                        <span class="ratings" style="width:60%"></span><!-- End .ratings -->
                                    </div><!-- End .product-ratings -->

                                    <a href="#" class="rating-link">( 6 Reviews )</a>
                                </div><!-- End .product-container -->

                                <div class="price-box">
                                    <span class="old-price">
                                                 <?php if($config->tipo_moneda == 'Soles'): ?>
                                                    S/.
                                                <?php elseif($config->tipo_moneda == 'Dolares'): ?>
                                                    $
                                                <?php endif; ?>
                                        <?php echo e($producto->precio_antes); ?></span>
                                    <span class="product-price">

                                        <?php if($config->tipo_moneda == 'Soles'): ?>
                                            S/.
                                        <?php elseif($config->tipo_moneda == 'Dolares'): ?>
                                            $
                                        <?php endif; ?>
                                        <?php echo e($producto->precio_ahora); ?></span>
                                </div><!-- End .price-box -->

                                <div class="product-desc">
                                    <p class="text-justify"><?php echo e($producto->resena); ?></p>
                                </div>

                                <div class="product-desc">
                                    <p class="text-justify" style="margin-bottom: 0 !important"><b>Stock actual: </b><?php echo e($producto->stock); ?> uni.</p>
                                    <?php if($producto->stock < 5): ?>
                                        <p style="color:#ff0000"><b>Quedan pocas unidades!</b></p>
                                    <?php endif; ?>
                                </div>

                                

                               <?php if(Auth::check()): ?>
                                    <form action="<?php echo e(route('agregar.carrito')); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <div class="product-action product-all-icons">
                                            <div class="product-single-qty">
                                                <input class="horizontal-quantity form-control" name="cantidad" type="text">
                                                <input type="hidden" value="<?php echo e($producto->id); ?>" name="idproducto">
                                            </div>
    
                                            <button type="submit" class="paction add-cart" title="Agregar al carrito" style="cursor: pointer">
                                                <span>AL CARRITO</span>
                                            </button>
                                            
                                            <?php if(Session::has('danger')): ?>
                                                <p style="color:#ff5579"><?php echo e(Session::get('danger')); ?></p>
                                            <?php endif; ?>
                                            <?php if(Session::has('success')): ?>
                                                <p style="color:#232f3e "><b><?php echo e(Session::get('success')); ?></b></p>
                                            <?php endif; ?>
                                            
                                        </div>
                                    </form>
                                <?php else: ?>
                                    <div class="product-action product-all-icons">
                                        <div class="product-single-qty">
                                            <input class="horizontal-quantity form-control" type="text" min="1" max="3">
                                        </div>

                                        <button class="paction add-cart" title="Agregar al carrito" style="cursor: pointer">
                                            <span>AL CARRITO</span>
                                        </button>
                                        
                                        <p style="color:#232f3e "><b>Debe iniciar sesión para comprar.</b></p>
                                    </div>
                                    
                               <?php endif; ?>

                                
                            </div><!-- End .product-single-details -->
                        </div><!-- End .col-lg-5 -->
                    </div><!-- End .row -->
                </div><!-- End .product-single-container -->

                <div class="product-single-tabs">
                    <ul class="nav nav-tabs" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link active" id="product-tab-desc" data-toggle="tab" href="#product-desc-content" role="tab" aria-controls="product-desc-content" aria-selected="true">Detalles</a>
                        </li>
                       
                        <li class="nav-item">
                            <a class="nav-link" id="product-tab-reviews" data-toggle="tab" href="#product-reviews-content" role="tab" aria-controls="product-reviews-content" aria-selected="false">Resenas</a>
                        </li>
                    </ul>
                    <div class="tab-content">
                        <div class="tab-pane fade show active" id="product-desc-content" role="tabpanel" aria-labelledby="product-tab-desc">
                            <div class="product-desc-content">
                               <?php echo $producto->contenido?>
                            </div><!-- End .product-desc-content -->
                        </div><!-- End .tab-pane -->

                        

                        <div class="tab-pane fade" id="product-reviews-content" role="tabpanel" aria-labelledby="product-tab-reviews">
                            <div class="product-reviews-content">
                               

                                <div class="add-product-review">
                                    <h3 class="text-uppercase heading-text-color font-weight-semibold">COMENTARIOS</h3>
                                    <p>Solo los usuarios que compraron este producto, pueden comentar.</p>

                                    <div class="row">

                                        <?php if(count($resenas) == 0): ?>
                                            <div class="col-lg-12">
                                                <p><b>No hay ninguna resena en este producto :(</b></p>
                                            </div>
                                        <?php else: ?>
                                            <?php $__currentLoopData = $resenas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="col-lg-12">
                                                    <div class="card">
                                                        <div class="card-body">
                                                            <h4><?php echo e($item->name); ?> <?php echo e($item->fullname); ?></h4>
                                                            <p style="margin-bottom: 0px !important"><?php echo e($item->resena); ?></p>
                                                            <span class="text-muted" style="font-size: 1rem;"><b>Fecha de publicación: </b> <?php echo e($item->createAt); ?></span>
                                                            <?php if($item->foto_uno || $item->foto_dos || $item->foto_tres): ?>
                                                                <hr>
                                                                <div class="row">
                                                                    <div class="col-lg-12">
                                                                        <img src="<?php echo e(asset('resenas/'.$item->foto_uno)); ?>" style="width: 100px;float:left;margin-right:10px">
                                                                        <img src="<?php echo e(asset('resenas/'.$item->foto_dos)); ?>" style="width: 100px;float:left;margin-right:10px">
                                                                        <img src="<?php echo e(asset('resenas/'.$item->foto_tres)); ?>" style="width: 100px;float:left;margin-right:10px">
                                                                    </div>
                                                                
                                                                </div>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                        
                                    </div>
                                    
                                </div><!-- End .add-product-review -->
                            </div><!-- End .product-reviews-content -->
                        </div><!-- End .tab-pane -->
                    </div><!-- End .tab-content -->
                </div><!-- End .product-single-tabs -->
            </div><!-- End .col-lg-9 -->

            <div class="sidebar-overlay"></div>
            <div class="sidebar-toggle"><i class="icon-sliders"></i></div>
            <aside class="sidebar-product col-lg-3 padding-left-lg mobile-sidebar">
                <div class="sidebar-wrapper">
                    <div class="widget widget-brand">
                        <a href="#">
                            <img src="<?php echo e(asset('assets/images/logo-black.png')); ?>" alt="brand name">
                        </a>
                    </div><!-- End .widget -->

                    <div class="widget widget-info">
                        <ul>
                            <li>
                                <i class="icon-shipping"></i>
                                <h4>ENVIO<br>GRATIS</h4>
                            </li>
                            <li>
                                <i class="icon-us-dollar"></i>
                                <h4>100% DE GARANTÍA<br>DE TU DINERO</h4>
                            </li>
                            <li>
                                <i class="icon-online-support"></i>
                                <h4>SOPORTE<br> 24/7</h4>
                            </li>
                        </ul>
                    </div><!-- End .widget -->

                    <?php 
                
                        $config = DB::table('configuraciones')
                        ->first();
                    ?>

                    <div class="widget widget-banner">
                        <div class="banner banner-image">
                            <a href="#">
                                <img src="<?php echo e(asset('config/'.$config->banner_producto)); ?>" alt="Banner Desc">
                            </a>
                        </div><!-- End .banner -->
                    </div><!-- End .widget -->

                    <div class="widget widget-featured">
                        <h3 class="widget-title">Ofertas</h3>
                        
                        <div class="widget-body">
                            <div class="owl-carousel widget-featured-products">
                                <div class="featured-col">

                                    <?php $__currentLoopData = $features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="product-default left-details product-widget">
                                            <figure>
                                                <a href="<?php echo e(route('producto',$item->slug)); ?>">
                                                    <img src="<?php echo e(asset('poster/'.$item->poster)); ?>">
                                                </a>
                                            </figure>
                                            <div class="product-details">
                                                <h2 class="product-title">
                                                    <a href="<?php echo e(route('producto',$item->slug)); ?>" title="<?php echo e($item->titulo); ?>"><?php echo e($item->titulo); ?></a>
                                                </h2>
                                                <div class="ratings-container">
                                                    <div class="product-ratings">
                                                        <span class="ratings" style="width:100%"></span><!-- End .ratings -->
                                                        <span class="tooltiptext tooltip-top"></span>
                                                    </div><!-- End .product-ratings -->
                                                </div><!-- End .product-container -->
                                                <div class="price-box">
                                                    <span class="product-price">
                                                        <?php if($config->tipo_moneda == 'Soles'): ?>
                                                            S/.
                                                        <?php elseif($config->tipo_moneda == 'Dolares'): ?>
                                                            $
                                                        <?php endif; ?>
                                                        <?php echo e($item->precio_ahora); ?></span>
                                                </div><!-- End .price-box -->
                                            </div><!-- End .product-details -->
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                               
                                </div><!-- End .featured-col -->

                                
                            </div><!-- End .widget-featured-slider -->
                        </div><!-- End .widget-body -->
                    </div><!-- End .widget -->
                </div>
            </aside><!-- End .col-md-3 -->
        </div><!-- End .row -->
    </div><!-- End .container -->
</main>
<?php $__env->startPush('scripts'); ?>
    <script>
       
    </script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.users', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\tienda\resources\views/detalle_producto.blade.php ENDPATH**/ ?>