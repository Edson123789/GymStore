<?php $__env->startSection('user-content'); ?>
<main class="main">
    <div class="container">
        <div class="row mt-4 mb-4">
            <div class="col-lg-9 order-lg-last dashboard-content">
                <h2>Nueva dirección</h2>
                
               <form action="<?php echo e(route('direccion_registro')); ?>" role="form" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="row">

                        <?php if(Session::has('success')): ?>
                            <div class="col-sm-12 form-group">
                                <div class="alert alert-success">
                                    <?php echo e(Session::get('success')); ?>

                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                            </div>
                        <?php endif; ?>
                        <?php if(Session::has('danger')): ?>
                        <div class="col-sm-12 form-group">
                            <div class="alert alert-danger">
                                <?php echo e(Session::get('danger')); ?>

                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                        </div>
                        <?php endif; ?>

                        <div class="col-lg-12 form-group">
                            <label><b>Dirección</b></label>
                            <textarea name="direccion" class="form-control" style="min-height: 100px !important;" placeholder="Ingrese su nueva dirección"></textarea>
                        </div>
                        <div class="col-lg-3 col-md-6 form-group">
                            <label><b>País</b></label>
                            <select name="pais" class="form-control">
                                <?php $__currentLoopData = $paises; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->name); ?>"><?php echo e($item->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-lg-3 col-md-6 form-group">
                            <label><b>Región</b></label>
                            <input type="text" class="form-control" placeholder="Región" name="region">
                        </div>
                        <div class="col-lg-3 col-md-6 form-group">
                            <label><b>Ciudad</b></label>
                            <input type="text" class="form-control" placeholder="Ciudad" name="ciudad">
                        </div>
                        <div class="col-lg-3 col-md-6 form-group">
                            <label><b>Código postal</b></label>
                            <input type="text" class="form-control" placeholder="ZIP code" name="zip">
                        </div>
                        <div class="col-sm-12 text-right">
                            <button type="submit" class="btn btn-primary btn-sm">Registrar</button>
                        </div>
                    </div>
               </form>

               <hr>

               <h2>Mis direcciones</h2>

               <div class="row mt-4">

                <?php $__currentLoopData = $direcciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-6 form-group">
                        <div class="card">  
                            <div class="card-body">
                                <?php echo $item->direccion?>, <b>ZIP: </b> <?php echo e($item->zip); ?><br>
                                <span><b>País: </b> <?php echo e($item->pais); ?></span><br>
                                <span><b>Región: </b> <?php echo e($item->region); ?></span><br>
                                <span><b>Ciudad: </b> <?php echo e($item->ciudad); ?></span><br>
                            </div>
                            <div class="card-footer">
                                <button class="btn btn-danger btn-sm" style="background: #232f3e !important"
                                data-toggle="modal" data-target="#modal-<?php echo e($item->id); ?>">
                                    Eliminar
                                </button>

                            </div>
                        </div>
                    </div>
                    <form action="<?php echo e(route('direccion_eliminar',$item->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <input name="_method" type="hidden" value="DELETE">
                        <div class="modal fade" id="modal-<?php echo e($item->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog modal-dialog-centered" role="document" style="max-width: 500px !important;">
                              <div class="modal-content">
                                <div class="modal-header">
                                  <h4 class="modal-title" id="exampleModalLabel">Eliminar dirección</h4>
                                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                  </button>
                                </div>
                                <div class="modal-body">
                                  <p>Desea eliminar definitivamente la dirección?</p>
                                </div>
                                <div class="modal-footer">
                                  <button type="button" class="btn btn-secondary btn-sm" data-dismiss="modal">Cancelar</button>
                                  <button type="submit" class="btn btn-primary btn-sm" style="background: #e8a207 !important">Confirmar</button>
                                </div>
                              </div>
                            </div>
                        </div>
                    </form>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

               </div>


            </div><!-- End .col-lg-9 -->

            <aside class="sidebar col-lg-3">
                <div class="widget widget-dashboard">
                    <h3 class="widget-title">Cuenta</h3>

                    <ul class="list">
                        <li><a href="<?php echo e(route('cuenta')); ?>" style="background-color: #eee;"><i class="icon icon-user"></i> Mi perfíl</a></li>
                        <li class="active"><a><i class="icon icon-post"></i> Direcciones</a></li>
                    
                    </ul>
                </div><!-- End .widget -->
            </aside><!-- End .col-lg-3 -->
        </div>
    </div>
</main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.users', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\tienda\resources\views/perfil/direccion.blade.php ENDPATH**/ ?>