<?php $__env->startSection('user-content'); ?>
<main class="main">
    <nav aria-label="breadcrumb" class="breadcrumb-nav">
        <div class="container">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('inicio')); ?>"><i class="icon-home"></i></a></li>
                <li class="breadcrumb-item active" aria-current="page">Carrito de compras</li>
            </ol>
        </div><!-- End .container -->
    </nav>

    <div class="container">
        <div class="row">
            <div class="col-lg-8">
                <?php if(Session::has('danger')): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <?php echo e(Session::get('danger')); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                        </button>
                    </div> 
                <?php endif; ?>

                <div class="cart-table-container">
                    <?php if(count($carrito)>0): ?>
                        <table class="table table-cart">
                            <thead>
                                <tr>
                                    <th class="product-col">Producto</th>
                                    <th class="price-col">Precio</th>
                                    <th class="qty-col">Cantidad</th>
                                    <th>Subtotal</th>
                                </tr>
                            </thead>
                            <?php $__currentLoopData = $carrito; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tbody>
                                    <tr class="product-row">
                                        <td class="product-col">
                                            <figure class="product-image-container">
                                                <a href="<?php echo e(route('productos')); ?>" class="product-image">
                                                    <img src="<?php echo e(asset('poster/'.$item->poster)); ?>" alt="product">
                                                </a>
                                            </figure>
                                            <h2 class="product-title">
                                                <a href="<?php echo e(route('producto',$item->slug)); ?>"><?php echo e($item->titulo); ?></a>
                                            </h2>
                                        </td>
                                        <td>$<?php echo e($item->precio_ahora); ?></td>
                                        <td>
                                            <?php echo e($item->cantidad); ?> uni.
                                        </td>
                                        <td class="total_neto">$<?php echo $item->precio_ahora * $item->cantidad?></td>
                                    </tr>
                                    <tr class="product-action-row">
                                        <td colspan="4" class="clearfix">
                                        
                                            
                                            <div class="float-right">
                                                <form action="<?php echo e(route('quitar.carrito',$item->id)); ?>" method="POST" style="margin-bottom: 0px !important; cursor:pointer">
                                                    <?php echo csrf_field(); ?>
                                                    <input name="_method" type="hidden" value="DELETE">
                                                    <button type="submit" title="Quitar producto" style="border: none !important;
                                                    background: none !important;" class="btn-remove"><span class="sr-only">Eliminar</span></button>
                                                </form>
                                            </div><!-- End .float-right -->
                                        </td>
                                    </tr>

                                
                                </tbody>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <tfoot>
                                <tr>
                                    <td colspan="4" class="clearfix">
                                        <div class="float-left">
                                            <a href="<?php echo e(route('productos')); ?>" class="btn btn-outline-secondary">Continuar comprando</a>
                                        </div><!-- End .float-left -->

                                    
                                    </td>
                                </tr>
                            </tfoot>
                        </table>
                    <?php else: ?>
                        <h1 class="mt-4" style="font-weight: 300">Tu carrito está vacio.</h1>
                    <?php endif; ?>
                </div><!-- End .cart-table-container -->

               
            </div><!-- End .col-lg-8 -->

            <div class="col-lg-4">
                <div class="cart-summary">
                    <h3>Detalles</h3>

                    <h4>
                        <a data-toggle="collapse" href="#total-estimate-section" class="collapsed" role="button" aria-expanded="false" aria-controls="total-estimate-section">ENVIO</a>
                    </h4>

                    <div class="collapse show" id="total-estimate-section">
                        <form action="#">
                            <div class="form-group form-group-sm">
                                <label>Direcciones</label>
                                <div class="select-custom">
                                    <select class="form-control form-control-sm" id="direccion">
                                        <?php $__currentLoopData = $direcciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->direccion); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                       
                                    </select>
                                </div><!-- End .select-custom -->
                            </div><!-- End .form-group -->

                           
                        </form>
                    </div><!-- End #total-estimate-section -->

                    <table class="table table-totals">
                        <tbody>
                            <tr>
                                <td>Total</td>
                                <td>$<?php echo e($total); ?></td>
                            </tr>

                            <tr>
                                <td>Descuento</td>
                                <td>$0.00</td>
                            </tr>
                        </tbody>
                        <tfoot>
                            <tr>
                                <td>Total a pagar</td>
                                <td>$<?php echo e($total); ?></td>
                            </tr>
                        </tfoot>
                    </table>

                    <div class="checkout-methods">
                        
                        <?php if(count($carrito)>0): ?>
                            <div id="paypal-button-container">                                                                     
                            </div>
                        <?php else: ?>
                            
                        <?php endif; ?>
                        <script src="https://www.paypalobjects.com/api/checkout.js"></script>
                        
                    </div><!-- End .checkout-methods -->
                </div><!-- End .cart-summary -->
            </div><!-- End .col-lg-4 -->
        </div><!-- End .row -->
    </div><!-- End .container -->

    <div class="mb-6"></div><!-- margin -->
</main>
<?php $__env->startPush('scripts'); ?>
<script>



    paypal.Button.render({
    env: 'sandbox', 
    style: {

        label: 'paypal',  // checkout | credit | pay | buynow | generic
        size:  'responsive', // small | medium | large | responsive
        shape: 'pill',   // pill | rect
        color: 'gold'   // gold | blue | silver | black
    },


    client: {
        sandbox:    'ATICHcu5eXDSWJOQAIzZ08kcI89lXFZpY2TmbpN0ZlL6zHLVkplziHsWWSujjR5cPGkbRcIzNSQHgAVL',
        production: 'AUuGuYNFfB0NDp6ASTV3Pmnpib4OCV-n5UzdrM-cJmiJ20LdmxaMreRuX8XLA4w8NIzzHgPaYSxp5bAI'
    },

 

    payment: function(data, actions) {
        if('<?php echo $authenticate?>'){

            return actions.payment.create({
                payment: {
                    transactions: [
                        {
                            amount: { total: '<?php echo $total?>', currency: 'USD' },
                            description:"Compras en Devcthemes, TOTAL A PAGAR: <?php echo $total?>USD" ,
                        }
                    ]
                }
            });
        }else{
            window.location.href = "<?php echo e(URL::to('')); ?>"
        }
    },

    
    onAuthorize: function(data, actions) {
   
        
        return actions.payment.execute().then(function() {
           
           var productos = '<?php echo $data_productos?>';
           var cantidades = '<?php echo $data_cantidades?>';
           var transanccion  = data.paymentID;
           var codigo = '<?php echo uniqid();?>';
           var direccion = document.getElementById('direccion').value;
           window.location="../../../../venta/checkout/detalles/"+codigo+"/"+transanccion+"/"+productos+"/"+cantidades+"/"+direccion;

        });
    }

}, '#paypal-button-container');
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.users', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\tienda\resources\views/carrito.blade.php ENDPATH**/ ?>