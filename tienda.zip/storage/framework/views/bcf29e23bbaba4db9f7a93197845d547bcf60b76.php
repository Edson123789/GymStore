<?php $__env->startSection('auth'); ?>
<main class="main h-100 w-100">
    <div class="container h-100">
        <div class="row h-100">
            <div class="col-sm-10 col-md-8 col-lg-6 mx-auto d-table h-100">
                <div class="d-table-cell align-middle">

                    <div class="text-center mt-4">
                        <h1 class="h2">Ecommerce</h1>
                        <p class="lead">
                            Sistema ecommerce con pasarelas de pago
                        </p>
                    </div>

                    <div class="card">
                        <div class="card-body">
                            <form method="POST" action="<?php echo e(route('login')); ?>" autocomplete="off">
                                <?php echo e(csrf_field()); ?>

                                <div class="m-sm-4">
                                    <div class="text-center">
                                        <img src="<?php echo e(asset('img/logo.png')); ?>" alt="Linda Miller" class="img-fluid" width="132" height="132" />
                                    </div>
                           
                                        <div class="form-group">
                                            <label><b>Email</b></label>
                                            <input class="form-control form-control-lg" type="email <?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" />
                                            <?php if($errors->has('email')): ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($errors->first('email')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="form-group">
                                            <label><b>Password</b></label>
                                            <input autocomplete="new-password" class="form-control form-control-lg <?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" type="password" name="password" />
                                            <?php if($errors->has('password')): ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($errors->first('password')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                        
                                        
                                            <button type="submit" class="btn btn-lg btn-primary">Ingresar</button>
                                        </div>
                              
                                </div>

                            </form>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\tienda\resources\views/auth/login.blade.php ENDPATH**/ ?>